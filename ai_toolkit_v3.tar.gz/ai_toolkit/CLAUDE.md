# 🤖 Claude Instructions — AI Toolkit

## 🚨 ПЕРВОЕ ДЕЙСТВИЕ

Прочитай `_AI_INCLUDE/` — там правила этого проекта.

```
_AI_INCLUDE/
├── PROJECT_CONVENTIONS.md  ← Архитектура, запреты, правила
└── WHERE_IS_WHAT.md        ← Где что искать
```

---

## 📌 Это проект AI Toolkit

Инструмент для создания AI-friendly проектов. Генерирует:
- Структуру проекта
- AI конфиги (.cursorrules, copilot-instructions.md, CLAUDE.md)
- Scripts (bootstrap.sh, health_check.sh)
- Docker, CI/CD, Git

---

## 🏗️ Ключевая архитектура

```
src/
├── core/           # Базовые компоненты
│   ├── constants.py    ← ВСЕ константы здесь!
│   └── config.py       ← Работа с конфигом
├── generators/     # Генераторы файлов
│   ├── ai_configs.py   ← .cursorrules, copilot, CLAUDE.md
│   ├── scripts.py      ← bootstrap.sh, health_check.sh
│   ├── docker.py       ← Dockerfile
│   └── ci_cd.py        ← GitHub Actions
├── commands/       # CLI команды
│   ├── create.py       ← Создание проекта
│   └── cleanup.py      ← Очистка
└── cli.py          # Главный CLI
```

---

## ⚠️ ЗАПРЕТЫ

1. **НЕ создавай venv/** внутри этого проекта
2. **НЕ меняй constants.py** без понимания связей
3. **НЕ добавляй зависимости** без необходимости

---

## ✅ Как добавить новую фичу

### Новый генератор:
1. Создать в `src/generators/new_generator.py`
2. Добавить в `src/generators/__init__.py`
3. Вызвать в `src/commands/create.py`

### Новая команда:
1. Создать в `src/commands/new_command.py`
2. Добавить в `src/commands/__init__.py`
3. Добавить в `src/cli.py` (меню + argparse)

### Новый шаблон:
1. Добавить в `TEMPLATES` в `src/core/constants.py`
2. Добавить генерацию в `src/commands/create.py`

---

## 🧪 Тестирование

```bash
# Запуск
python __main__.py

# CLI
python __main__.py create test_bot --template bot --ai copilot

# Проверка
./scripts/health_check.sh (если есть)
```

---

## 📁 Быстрые ссылки

| Нужно | Файл |
|-------|------|
| Все шаблоны | `src/core/constants.py` → `TEMPLATES` |
| Все IDE | `src/core/constants.py` → `IDE_CONFIGS` |
| Генерация AI файлов | `src/generators/ai_configs.py` |
| Главная логика создания | `src/commands/create.py` |
| CLI меню | `src/cli.py` |
