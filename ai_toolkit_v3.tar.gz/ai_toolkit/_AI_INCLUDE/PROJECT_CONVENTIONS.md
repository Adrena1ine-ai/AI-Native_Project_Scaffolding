# 🛠️ AI Toolkit — Project Conventions

## 📌 Этот файл обязателен к прочтению AI-ассистентами!

---

## 🏗️ Архитектура проекта

```
ai_toolkit/
├── src/                    # Исходный код
│   ├── core/               # Базовые компоненты
│   │   ├── config.py       # Конфигурация
│   │   ├── constants.py    # Константы (COLORS, TEMPLATES)
│   │   └── file_utils.py   # Работа с файлами
│   ├── generators/         # Генераторы файлов
│   │   ├── ai_configs.py   # .cursorrules, copilot-instructions.md
│   │   ├── scripts.py      # bootstrap.sh, health_check.sh
│   │   ├── docker.py       # Dockerfile, docker-compose
│   │   ├── ci_cd.py        # GitHub Actions
│   │   ├── git.py          # .gitignore, git init
│   │   └── project_files.py # requirements, config.py, README
│   ├── commands/           # CLI команды
│   │   ├── create.py       # Создание проекта
│   │   ├── cleanup.py      # Очистка
│   │   ├── migrate.py      # Миграция
│   │   ├── health.py       # Health check
│   │   └── update.py       # Обновление
│   └── cli.py              # Главный CLI
├── templates/              # Внешние шаблоны (TODO)
├── plugins/                # Плагины (TODO)
├── gui/                    # GUI (TODO)
├── tests/                  # Тесты
└── docs/                   # Документация
```

---

## 🚫 ЗАПРЕТЫ

### При работе с этим проектом AI НЕ должен:

1. **НЕ создавать venv внутри ai_toolkit/**
   - Venv должен быть в `../_venvs/ai_toolkit-venv`

2. **НЕ модифицировать без понимания:**
   - `src/core/constants.py` — все константы связаны
   - `src/generators/*.py` — генерируют код, тестировать после изменений

3. **НЕ добавлять зависимости без необходимости**
   - Проект должен работать с минимумом зависимостей
   - Обязательная: `pyyaml`
   - Опциональные: `pytest`, `tkinter` (GUI)

---

## ✅ ПРАВИЛЬНЫЕ ДЕЙСТВИЯ

### Добавление нового генератора:

1. Создать файл в `src/generators/`
2. Добавить функцию `generate_xxx(project_dir, project_name, ...)`
3. Импортировать в `src/generators/__init__.py`
4. Вызвать в `src/commands/create.py`

### Добавление новой команды:

1. Создать файл в `src/commands/`
2. Добавить `cmd_xxx()` для интерактивного режима
3. Добавить в `src/commands/__init__.py`
4. Добавить в `src/cli.py` (меню + argparse)

### Добавление нового шаблона:

1. Добавить в `TEMPLATES` в `src/core/constants.py`
2. Добавить генерацию модулей в `src/commands/create.py`
3. Обновить `generate_requirements()` в `src/generators/project_files.py`

---

## 📏 Code Style

- Python 3.10+
- Type hints обязательны
- Docstrings для публичных функций
- f-strings для форматирования
- pathlib.Path вместо os.path
- Максимум 100 символов в строке

---

## 🧪 Тестирование

```bash
# Запуск тестов
pytest tests/ -v

# Ручное тестирование
python __main__.py create test_bot --template bot --ai copilot
./scripts/health_check.sh
```

---

## 📁 Ключевые файлы

| Файл | Зачем |
|------|-------|
| `src/core/constants.py` | ВСЕ константы, шаблоны, конфиги |
| `src/commands/create.py` | Главная логика создания проекта |
| `src/generators/ai_configs.py` | Генерация файлов для AI |
| `src/cli.py` | CLI интерфейс |

---

## 🔄 Flow создания проекта

```
1. cli.py → select_ide()
2. cli.py → cmd_create()
3. commands/create.py → create_project()
   ├── generators/ai_configs.py → AI файлы
   ├── generators/scripts.py → Скрипты
   ├── generators/project_files.py → Основные файлы
   ├── commands/create.py → Модули (bot, db, api)
   ├── generators/docker.py → Docker
   ├── generators/ci_cd.py → CI/CD
   └── generators/git.py → Git init
```
