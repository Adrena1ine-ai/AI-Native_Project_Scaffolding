"""
🛠️ AI Toolkit v3.0
====================
Создание и управление AI-friendly проектами

Возможности:
- Создание проектов (bot, webapp, fastapi, parser, monorepo)
- Очистка грязных проектов
- Миграция существующих проектов
- Health check
- Docker и CI/CD интеграция
- GUI интерфейс
- Плагины
"""

__version__ = "3.0.0"
__author__ = "Mickhael"
