from __future__ import annotations

import os
import re
from pathlib import Path
from datetime import datetime

# ============================================================
# СБОРЩИК "ОДИН ФАЙЛ ДЛЯ LLM"
# - Пишет оглавление (структура проекта от корня)
# - Затем собирает содержимое ключевых текстовых файлов
# - Пропускает БД/кэш/бинарники/слишком большие файлы
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT_FILE = PROJECT_ROOT / "FULL_PROJECT_CODE.txt"

# Файлы, которые никогда не должны попадать в дамп (чтобы не было рекурсии и "самосборки")
# Важно: сравниваем по имени (Path.name), т.к. сборщик ходит от корня проекта.
IGNORE_FILES_BY_NAME = {
    Path(__file__).name,              # сам сборщик
    "запуск файла итога проекта.bat", # батник запуска сборщика
    OUTPUT_FILE.name,                 # итоговый дамп
}

# Те же исключения, но по абсолютному пути (более надёжно на Windows при любых нюансах Unicode)
try:
    IGNORE_PATHS = {
        Path(__file__).resolve(),
        OUTPUT_FILE.resolve(),
        (PROJECT_ROOT / "запуск файла итога проекта.bat").resolve(),
    }
except Exception:
    IGNORE_PATHS = set()

# Единая проверка "жёстких" исключений (и для дерева, и для контента)
def _is_explicitly_ignored_file(path: Path) -> bool:
    try:
        if path.resolve() in IGNORE_PATHS:
            return True
    except Exception:
        pass
    name = path.name
    if name in IGNORE_FILES_BY_NAME:
        return True
    for pat in IGNORE_FILE_NAME_PATTERNS:
        if pat.match(name):
            return True
    return False

# На всякий случай: не включаем старые/альтернативные дампы, чтобы не раздувать файл и не собирать "сборку сборки"
IGNORE_FILE_NAME_PATTERNS = [
    re.compile(r"^FULL_PROJECT_CODE.*\.txt$", flags=re.I),
]

# Что игнорировать целиком
IGNORE_DIRS = {
    ".git",
    ".cursor",
    ".pytest_cache",
    "__pycache__",
    "venv",
    "env",
    ".idea",
    ".vscode",
    "data",  # база/логи/персистенс
}

# Явно разрешённые dot-файлы (если есть)
ALLOW_DOTFILES = {
    ".gitignore",
    ".env.example",
    ".editorconfig",
}

# Расширения, которые обычно важны для понимания проекта
INCLUDE_EXTENSIONS = {
    ".py",
    ".txt",
    ".md",
    ".bat",
    ".json",
    ".yml",
    ".yaml",
    ".toml",
    ".ini",
    ".cfg",
    ".env",
}

# Явно важные файлы по имени (даже если без расширения)
INCLUDE_FILENAMES = {
    "requirements.txt",
    "README.md",
    "LICENSE",
}

# Жёсткий игнор по расширениям (бинарники/медиа/БД)
IGNORE_EXTENSIONS = {
    ".db",
    ".sqlite",
    ".sqlite3",
    ".wal",
    ".shm",
    ".pkl",
    ".pyc",
    ".pyd",
    ".exe",
    ".dll",
    ".so",
    ".dylib",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".bmp",
    ".ico",
    ".mp4",
    ".mov",
    ".avi",
    ".mkv",
    ".zip",
    ".rar",
    ".7z",
    ".pdf",
}

# Ограничения по размеру (чтобы не раздувать один файл до гигабайт)
MAX_FILE_BYTES = 512_000      # 500 KB на файл
MAX_TOTAL_BYTES = 12_000_000  # 12 MB на весь дамп


def _is_ignored_dir(dir_name: str) -> bool:
    return dir_name in IGNORE_DIRS


def _is_text_candidate(path: Path) -> bool:
    name = path.name
    if _is_explicitly_ignored_file(path):
        return False
    if name.startswith(".") and name not in ALLOW_DOTFILES:
        return False

    ext = path.suffix.lower()
    if ext in IGNORE_EXTENSIONS:
        return False

    if name in INCLUDE_FILENAMES:
        return True

    if ext in INCLUDE_EXTENSIONS:
        # .env по умолчанию НЕ включаем (секреты), только если это пример
        if ext == ".env" and name != ".env.example":
            return False
        return True

    return False


def _safe_read_text(path: Path) -> str | None:
    # Пробуем utf-8, затем cp1251 (часто в винде), затем utf-8-sig
    for enc in ("utf-8", "utf-8-sig", "cp1251"):
        try:
            return path.read_text(encoding=enc, errors="strict")
        except Exception:
            continue
    # Последний шанс: заменить битые символы
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None


def _walk_project(root: Path) -> list[Path]:
    files: list[Path] = []
    for base, dirs, filenames in os.walk(root):
        base_path = Path(base)
        dirs[:] = [d for d in dirs if not _is_ignored_dir(d)]
        for fn in filenames:
            p = base_path / fn
            if not p.is_file():
                continue
            # Не включаем явно исключённые файлы даже в оглавление
            if _is_explicitly_ignored_file(p):
                continue
            files.append(p)
    return files


def _extract_requirements(root: Path) -> list[str]:
    req = root / "requirements.txt"
    if not req.exists():
        return []
    content = _safe_read_text(req) or ""
    items: list[str] = []
    for line in content.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        items.append(s)
    return items


def _extract_db_tables(root: Path) -> list[str]:
    db_file = root / "database" / "db.py"
    if not db_file.exists():
        return []
    content = _safe_read_text(db_file) or ""
    # Ищем CREATE TABLE IF NOT EXISTS <name>
    tables = re.findall(r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+([a-zA-Z_][a-zA-Z0-9_]*)", content, flags=re.I)
    # Уникализируем, сохраняя порядок
    seen = set()
    out: list[str] = []
    for t in tables:
        tl = t.lower()
        if tl in seen:
            continue
        seen.add(tl)
        out.append(t)
    return out


def _extract_handler_registrations(root: Path) -> list[str]:
    """
    Достаём из main.py список add_handler(...) и register_handlers(...).
    Это не AST-парсер, но для итогового файла достаточно стабильного regex.
    """
    main_file = root / "main.py"
    if not main_file.exists():
        return []
    s = _safe_read_text(main_file) or ""

    lines = s.splitlines()
    results: list[str] = []

    # Примитивный “сбор выражения” для app.add_handler( ... )
    i = 0
    while i < len(lines):
        line = lines[i]
        if "app.add_handler" in line:
            expr = line.strip()
            # собираем многострочный вызов до закрывающей ')'
            open_parens = expr.count("(") - expr.count(")")
            j = i + 1
            while open_parens > 0 and j < len(lines):
                nxt = lines[j].strip()
                expr += " " + nxt
                open_parens += nxt.count("(") - nxt.count(")")
                j += 1
            i = j - 1

            # Вытащим тип хендлера + pattern/group/block если есть
            handler_type = None
            m = re.search(r"add_handler\(\s*([A-Za-z_][A-Za-z0-9_\.]*)", expr)
            if m:
                handler_type = m.group(1)
            pattern = None
            pm = re.search(r"pattern\s*=\s*([\"'])(.+?)\\1", expr)
            if pm:
                pattern = pm.group(2)
            group = None
            gm = re.search(r"group\s*=\s*(-?\d+)", expr)
            if gm:
                group = gm.group(1)
            block = None
            bm = re.search(r"block\s*=\s*(True|False)", expr)
            if bm:
                block = bm.group(1)

            parts = []
            parts.append(handler_type or "app.add_handler(...)")
            if pattern:
                parts.append(f"pattern={pattern!r}")
            if group is not None:
                parts.append(f"group={group}")
            if block is not None:
                parts.append(f"block={block}")
            results.append(" - " + ", ".join(parts))
        i += 1

    # Отдельно отметим глобальную навигацию
    if "navigation.register_handlers(app)" in s:
        results.append(" - navigation.register_handlers(app)  # глобальные кнопки навигации")

    return results


def _extract_entrypoint_info(root: Path) -> list[str]:
    main_file = root / "main.py"
    if not main_file.exists():
        return []
    s = _safe_read_text(main_file) or ""
    out: list[str] = []

    # Persistence
    if "PicklePersistence" in s:
        m = re.search(r"PicklePersistence\\(filepath\\s*=\\s*([^\\)]+)\\)", s)
        if m:
            out.append(f"- persistence: PicklePersistence(filepath={m.group(1).strip()})")
        else:
            out.append("- persistence: PicklePersistence(...)")

    # run_polling
    if "run_polling" in s:
        rm = re.search(r"run_polling\\(([^\\)]*)\\)", s)
        if rm:
            out.append(f"- run_polling({rm.group(1).strip()})")
        else:
            out.append("- run_polling(...)")

    # error handler
    if "add_error_handler" in s:
        out.append("- global error handler registered")

    return out


def _write_project_brief(outfile, root: Path) -> None:
    outfile.write("=== КРАТКОЕ ОПИСАНИЕ ПРОЕКТА ===\n")
    outfile.write("Цель этого блока: дать LLM быстрый контекст по архитектуре до чтения всего кода.\n\n")

    outfile.write("**Точка входа**\n")
    if (root / "main.py").exists():
        outfile.write(f"- main.py (функция main запускает ApplicationBuilder/run_polling)\n")
    else:
        outfile.write("- main.py не найден\n")

    entry = _extract_entrypoint_info(root)
    if entry:
        outfile.write("\n**Рантайм/настройки приложения**\n")
        for line in entry:
            outfile.write(line + "\n")

    reqs = _extract_requirements(root)
    outfile.write("\n**Зависимости (requirements.txt)**\n")
    if reqs:
        for r in reqs:
            outfile.write(f"- {r}\n")
    else:
        outfile.write("- (не найден requirements.txt или пусто)\n")

    tables = _extract_db_tables(root)
    outfile.write("\n**База данных (SQLite)**\n")
    if tables:
        outfile.write("- таблицы: " + ", ".join(tables) + "\n")
    else:
        outfile.write("- таблицы не извлечены\n")

    handlers = _extract_handler_registrations(root)
    outfile.write("\n**Хендлеры (из main.py)**\n")
    if handlers:
        outfile.write("Список add_handler/register_handlers (тип, pattern/group/block если удалось извлечь):\n")
        for h in handlers:
            outfile.write(h + "\n")
    else:
        outfile.write("- хендлеры не извлечены\n")

    outfile.write("\n")


def _write_tree(outfile, root: Path, all_files: list[Path]) -> None:
    outfile.write("=== ОГЛАВЛЕНИЕ: СТРУКТУРА ПРОЕКТА ===\n")
    outfile.write(f"ROOT: {root.name}/\n\n")

    # Собираем структуру (папка -> файлы)
    by_dir: dict[Path, list[Path]] = {}
    for p in all_files:
        rel = p.relative_to(root)
        by_dir.setdefault(rel.parent, []).append(rel)

    for d in sorted(by_dir.keys(), key=lambda x: str(x)):
        indent = "  " * (0 if str(d) == "." else len(d.parts))
        dirname = f"{d}/" if str(d) != "." else f"{root.name}/"
        outfile.write(f"{indent}{dirname}\n")
        for rel in sorted(by_dir[d], key=lambda x: str(x)):
            outfile.write(f"{indent}  - {rel.name}\n")
        outfile.write("\n")


def collect_project_dump() -> Path:
    all_files = _walk_project(PROJECT_ROOT)

    # Отдельно: список файлов, которые войдут по правилам
    candidates: list[Path] = []
    skipped: list[tuple[str, str]] = []

    for p in all_files:
        rel = p.relative_to(PROJECT_ROOT)
        # пропускаем то, что точно не нужно
        if not _is_text_candidate(p):
            continue

        try:
            size = p.stat().st_size
        except Exception:
            skipped.append((str(rel), "stat_failed"))
            continue

        if size > MAX_FILE_BYTES:
            skipped.append((str(rel), f"too_large>{MAX_FILE_BYTES}"))
            continue

        candidates.append(p)

    total_written = 0
    with open(OUTPUT_FILE, "w", encoding="utf-8") as out:
        out.write("FULL PROJECT DUMP\n")
        out.write(f"Generated: {datetime.now().isoformat(timespec='seconds')}\n")
        out.write(f"Root: {PROJECT_ROOT}\n")
        out.write("\n")

        _write_project_brief(out, PROJECT_ROOT)

        _write_tree(out, PROJECT_ROOT, all_files)

        out.write("\n=== ВКЛЮЧЕНО В ДАМП ===\n")
        for p in sorted(candidates, key=lambda x: str(x.relative_to(PROJECT_ROOT))):
            rel = p.relative_to(PROJECT_ROOT)
            out.write(f"- {rel} ({p.stat().st_size} bytes)\n")
        out.write("\n")

        if skipped:
            out.write("=== ПРОПУЩЕНО (крупное/нечитаемое) ===\n")
            for rel, reason in skipped[:200]:
                out.write(f"- {rel} [{reason}]\n")
            if len(skipped) > 200:
                out.write(f"... и ещё {len(skipped) - 200}\n")
            out.write("\n")

        out.write("\n=== СОДЕРЖИМОЕ ФАЙЛОВ ===\n")
        for p in sorted(candidates, key=lambda x: str(x.relative_to(PROJECT_ROOT))):
            rel = p.relative_to(PROJECT_ROOT)
            content = _safe_read_text(p)
            if content is None:
                continue

            header = f"\n{'=' * 80}\nFILE: {rel}\nSIZE: {p.stat().st_size} bytes\n{'=' * 80}\n"
            chunk = header + content.rstrip() + "\n"

            # ограничение общего размера
            if total_written + len(chunk.encode("utf-8")) > MAX_TOTAL_BYTES:
                out.write("\n=== ОСТАНОВЛЕНО ПО ЛИМИТУ РАЗМЕРА ===\n")
                out.write(f"Достигнут лимит MAX_TOTAL_BYTES={MAX_TOTAL_BYTES}.\n")
                out.write(f"Последний добавленный файл: {rel}\n")
                break

            out.write(chunk)
            total_written += len(chunk.encode("utf-8"))
            # Важно: не используем emoji в print, чтобы не падать в Windows-консолях с cp1251
            print(f"Added: {rel}")

    print(f"\nDone! Output file: {OUTPUT_FILE}")
    return OUTPUT_FILE


if __name__ == "__main__":
    collect_project_dump()

