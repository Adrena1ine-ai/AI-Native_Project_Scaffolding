"""
ASCII wrapper for the project dump generator.

PowerShell/Windows terminals sometimes struggle with Cyrillic filenames in commands.
This wrapper allows running the dump generator via:

  python build_full_project_dump.py
"""

import Весь_бот_в_1_txt


if __name__ == "__main__":
    Весь_бот_в_1_txt.collect_project_dump()


