# 📜 AI Toolkit Manifesto

## 🎯 Главный принцип

> **Проект должен оставаться чистым для AI-ассистента**

---

## 🚫 Три главных запрета

### 1. Никогда не создавать venv внутри проекта

**Плохо:**
```
my_project/
├── venv/           ← 500 MB мусора
├── bot/
└── ...
```

**Хорошо:**
```
projects/
├── _venvs/
│   └── my_project-venv/    ← Здесь!
└── my_project/
    ├── bot/
    └── ...
```

**Почему?** AI (Cursor, Copilot) индексирует все файлы. 500 MB Python-пакетов = тормоза + шум в контексте.

---

### 2. Никогда не читать большие файлы целиком

**Плохо:**
```python
content = open("logs/bot.log").read()  # 100 MB в память
```

**Хорошо:**
```bash
tail -50 logs/bot.log
head -10 data/export.csv
sqlite3 db.sqlite3 ".schema"
```

**Почему?** Контекст AI ограничен. 100 MB лога = потеря важной информации.

---

### 3. Всегда проверять перед созданием

**Плохо:**
```
Создаю новый файл utils.py...
# А он уже есть в bot/utils/
```

**Хорошо:**
```
1. Читаю _AI_INCLUDE/WHERE_IS_WHAT.md
2. Проверяю существующие файлы
3. Создаю только если нужно
```

---

## ✅ Правильная структура

```
project/
├── _AI_INCLUDE/              # Правила для AI
│   ├── PROJECT_CONVENTIONS.md
│   └── WHERE_IS_WHAT.md
├── .cursorrules              # Cursor
├── .cursorignore             # Cursor ignore
├── .github/
│   ├── copilot-instructions.md  # Copilot
│   └── workflows/            # CI/CD
├── CLAUDE.md                 # Claude
├── scripts/
│   ├── bootstrap.sh          # Создание venv вне проекта
│   ├── health_check.sh       # Проверка здоровья
│   └── context.py            # Context Switcher
├── bot/                      # Код бота
├── database/                 # База данных
├── logs/                     # Логи (gitignored)
├── data/                     # Данные (gitignored)
├── Dockerfile
├── docker-compose.yml
└── requirements.txt
```

---

## 🎮 Context Switcher

Когда AI тупит на большом проекте:

```bash
python scripts/context.py bot     # Видит только bot/
python scripts/context.py webapp  # Видит только webapp/
python scripts/context.py all     # Видит всё
```

Обновляет `.cursorignore` чтобы скрыть ненужные модули.

---

## 🛡️ Защиты

1. **pre-commit hook** — блокирует коммит если venv в проекте
2. **health_check.sh** — проверяет правильность настройки
3. **.cursorignore** — скрывает мусор от AI

---

## 📋 Чеклист нового проекта

- [ ] venv создан в `../_venvs/`
- [ ] `_AI_INCLUDE/` существует
- [ ] `.cursorrules` настроен
- [ ] `.cursorignore` настроен
- [ ] `scripts/bootstrap.sh` работает
- [ ] `.env` создан из `.env.example`
- [ ] Git репозиторий инициализирован
- [ ] `health_check.sh` проходит
